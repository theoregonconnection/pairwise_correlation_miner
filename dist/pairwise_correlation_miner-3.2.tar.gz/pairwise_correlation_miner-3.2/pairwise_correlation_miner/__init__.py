__version__ = '3.2'

from .Pairwise_Correlation_Miner import execute_feature_target_pair_analysis
